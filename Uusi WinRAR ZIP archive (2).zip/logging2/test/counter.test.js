const request = require('supertest');
const assert = require('assert');
const app = require('../src/main'); // exportattu äsken

describe('Tally counter API', function () {
  it('GET /counter-reset nollaa laskurin', async function () {
    const res = await request(app)
      .get('/counter-reset')
      .expect(200);

    // paluuarvo voi olla esim. { count: 0 }
    assert.strictEqual(res.body.count, 0);
  });

  it('GET /counter-increase kasvattaa laskuria', async function () {
    // nollataan ensin varmuuden vuoksi
    await request(app).get('/counter-reset').expect(200);

    const res1 = await request(app)
      .get('/counter-increase')
      .expect(200);

    assert.strictEqual(res1.body.count, 1);

    const res2 = await request(app)
      .get('/counter-increase')
      .expect(200);

    assert.strictEqual(res2.body.count, 2);
  });

  it('GET /counter-read palauttaa nykyisen arvon', async function () {
    const res = await request(app)
      .get('/counter-read')
      .expect(200);

    assert.strictEqual(typeof res.body.count, 'number');
  });
});
