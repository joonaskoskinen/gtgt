const express = require('express');
const routes = require('./routes');
const logger = require('./logger');

const app = express();
const PORT = 3000;

logger.info('[MAIN] Starting');

app.use('/', routes);

// Käynnistä serveri vain kun ajetaan suoraan (node src/main.js)
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Kuuntele SIGINT (Ctrl+C) ja tee clea shutdown
process.on('SIGINT', () => {
  logger.info('[MAIN] Stopping');
  server.close(() => process.exit(0));
});

// Exportataan app, jotta mocha + supertest voi käyttää sovelluksen instanssia
module.exports = app;
