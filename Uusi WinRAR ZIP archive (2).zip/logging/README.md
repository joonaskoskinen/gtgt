# Logging library – Winston

Tässä tehtävässä toteutetaan lokitus Node.js-sovellukseen käyttäen Winston-kirjastoa.
Sovellus kirjoittaa lokiviestejä sekä konsoliin että tiedostoihin.

Projektin tarkoituksena on demonstroida Winstonin peruskäyttöä ja lokien tallentamista eri tasoilla.

---

## Vaatimukset

- Node.js 18
- Winston 3.11.0

---

## Asennus

Asenna projektin riippuvuudet:

```bash
npm install
Projektin rakenne
.
├── package.json
├── package-lock.json
├── README.md
└── src
    ├── logger.js
    └── main.js
Logger-konfiguraatio

Lokitus on toteutettu Winstonilla tiedostossa src/logger.js.

Logger käyttää:

JSON-muotoista lokitusta

aikaleimaa jokaisessa lokissa

useita transporteja

- Console
- logs/error.log (vain error-tason viestit)
- logs/combined.log (kaikki viestit)
Ohjelman suoritus

Aja sovellus komennolla:

node src/main.js

Ohjelma kirjoittaa erilaisia lokiviestejä, jotka näkyvät:

konsolissa

logs/combined.log

logs/error.log (vain error-viestit)

Esimerkki lokiviesteistä
{"level":"info","message":"This is an informational message.","timestamp":"2026-03-03T12:39:29.121Z"}
{"level":"warn","message":"This is a warning message.","timestamp":"2026-03-03T12:39:29.122Z"}
{"level":"error","message":"This is an error message.","timestamp":"2026-03-03T12:39:29.123Z"}